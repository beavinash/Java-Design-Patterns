package edu.umb.cs.cs680.hw01;

import static org.junit.Assert.*; 
import static org.hamcrest.CoreMatchers.*; 
import org.junit.Test;

public class CalculatorTest{ 
	@Test
	public void multiply3By4(){
		Calculator cut = new Calculator(); 
		float expected = 12;
		float actual = cut.multiply(3,4); assertThat(actual, is(expected)); 
	}
	
	@Test
	public void multiply4By18() {
		Calculator cut = new Calculator();
		float expected = 72;
		float actual = cut.multiply(4, 18);
		assertThat(actual, is(expected));
	}
	
	@Test 
	public void multiply100By100() {
		Calculator cut = new Calculator();
		float expected = 10000f;
		float actual = cut.multiply(100, 100);
		assertThat(actual, is(expected));
	}
	
	@Test
	public void divide3By2(){
		Calculator cut = new Calculator(); 
		float expected = 1.5f;
		float actual = cut.divide(3,2); assertThat(actual, is(expected)); 
	}
	
	@Test
	public void divide5By10() {
		Calculator cut = new Calculator();
		float expected = 0.5f;
		float actual = cut.divide(5, 10);
		assertThat(actual, is(expected));
	}
	
	@Test 
	public void divide99By10() {
		Calculator cut = new Calculator();
		float expected = 9.9f;
		float actual = cut.divide(99, 10);
		assertThat(actual, is(expected));
	}
	
	@Test(expected=IllegalArgumentException.class) 
	public void divide5By0(){
		Calculator cut = new Calculator();
		cut.divide(5,0); 
	}
}
